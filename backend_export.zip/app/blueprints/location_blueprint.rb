class LocationBlueprint < Blueprinter::Base
  identifier :id

  fields :address
end

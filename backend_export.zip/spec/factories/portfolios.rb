FactoryBot.define do
  factory :portfolio do
    
  end
end

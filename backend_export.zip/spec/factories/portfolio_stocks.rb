FactoryBot.define do
  factory :portfolio_stock do
    
  end
end
